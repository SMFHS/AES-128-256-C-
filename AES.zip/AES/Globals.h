#include <iostream>
using namespace std;

unsigned char Stored_Key_128[11][16];
unsigned char Stored_Key_256[15][16];
void Create_state_Matrix(unsigned char* state, unsigned char* pt)
{
    /*
    0 1 2 3                0 4 8 12
    4 5 6 7                1 5 9 13
    8 9 10 11              2 6 10 14
    12 13 14 15            3 7 11 15
    */

   state[0] = pt[0];    state[4] = pt[1];   state[8] = pt[2];       state[12] = pt[3];
   state[1] = pt[4];    state[5] = pt[5];   state[9] = pt[6];       state[13] = pt[7];
   state[2] = pt[8];    state[6] = pt[9];   state[10] = pt[10];     state[14] = pt[11];
   state[3] = pt[12];   state[7] = pt[13];  state[11] = pt[14];     state[15] = pt[15];
   
}

void Display_Hex(unsigned char* K)
{
    for(int i = 0; i<16; i++)
    {
        
        cout << hex << int(K[i]) << " ";
        
    }
    cout<<"\n"<<endl;

}

void Display_Hex_256(unsigned char* K)
{
    for(int i = 0; i<32; i++)
    {
        
        cout << hex << int(K[i]) << " ";
        
    }
    cout<<"\n"<<endl;

}


void Display(unsigned char* K)
{
    for(int i = 0; i<16; i++)
    {
        
        cout<<K[i];
        
    }
    cout<<"\n"<<endl;

}

void Add_Round_Key(unsigned char* state, unsigned char* k)
{
    unsigned char key_matrix[4][4];
    
    //initialising state and key matrix;

    int count = 0;
    for(int i = 0; i<4; i++)
    {
        for(int j = 0; j<4; j++)
        {
            key_matrix[j][i] = k[count++];
        }
    }

    //Xoring the matrices
    int x = 0;
    for(int i = 0; i<4; i++)
    {
        for(int j = 0; j<4; j++)
        {
            state[x++] ^= key_matrix[i][j];
        }
    }
}


void Display_Encrypted_Text(unsigned char* Text, int Size)
{
    cout<<"\nEncrypted Text: \n";
    for(int i = 0; i<Size; i++)
    {
        cout<<hex<<int(Text[i])<<" ";
    }
}

void Display_Decrypted_Text(unsigned char* Text, int Size)
{
    cout<<"\nDecrypted Text: \n";
    for(int i = 0; i<Size; i++)
    {
        cout<<Text[i];
    }
    cout<<"\n";
}

void Key_Input(unsigned char* Key)
{
        string input;
        int size = 0;

        Key_again:
        cout<<"\nEnter 32 Bit Key: ";
        //cin.ignore();
        getline(cin,input);
        size = input.size();

        cout<<"\n";
        
        if(size!=32)
        {
            cout<<"\nKey isn't 32 Byte"<<endl;
            goto Key_again;
        }
        
        for(int i = 0; i<size+1; i++)
        {
            Key[i] = input[i];
        }
}

int Text_Input(unsigned char* Plain_Text)
{
        string input;
        //cin.ignore();
        getline(cin,input);
        int size = input.size();
        for(int i = 0; i<size; i++)
        {
            Plain_Text[i] = input[i];
        }
        return size;
}

