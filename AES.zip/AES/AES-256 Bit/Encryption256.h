#include <iostream>
using namespace std;

//256 --- 14 rounds
//128 --- 10 rounds




void Substitute_Bytes(unsigned char* state)
{
    for(int i = 0; i<16; i++)
    {
        state[i] = SBox[state[i]];
    }
}
void Left_Shift_Rows(unsigned char* state)
{
    unsigned char temp[16];
    for(int i = 0; i<16; i++)
    {
        temp[i] = state[i];
    }

    state[0] = temp[0];
    state[1] = temp[1];
    state[2] = temp[2];
    state[3] = temp[3];

    state[4] = temp[5];
    state[5] = temp[6];
    state[6] = temp[7];
    state[7] = temp[4];

    state[8] = temp[10];
    state[9] = temp[11];
    state[10] = temp[8];
    state[11] = temp[9];

    state[12] = temp[15];
    state[13] = temp[12];
    state[14] = temp[13];
    state[15] = temp[14];
    /*
    0 1 2 3
    4 5 6 7
    8 9 10 11
    12 13 14 15
    */
}

void Mix_Columns(unsigned char* state)
{
    unsigned char Temp[16];

    Temp[0] = (Mult_2[state[0]] ^ Mult_3[state[4]] ^ state[8] ^ state[12]);
    Temp[4] = (state[0] ^ Mult_2[state[4]] ^ Mult_3[state[8]] ^ state[12]);
    Temp[8] = (state[0] ^ state[4] ^ Mult_2[state[8]] ^ Mult_3[state[12]]);
    Temp[12] = (Mult_3[state[0]] ^ state[4] ^ state[8] ^ Mult_2[state[12]]);

    Temp[1] = (Mult_2[state[1]] ^ Mult_3[state[5]] ^ state[9] ^ state[13]);
    Temp[5] = (state[1] ^ Mult_2[state[5]] ^ Mult_3[state[9]] ^ state[13]);
    Temp[9] = (state[1] ^ state[5] ^ Mult_2[state[9]] ^ Mult_3[state[13]]);
    Temp[13] = (Mult_3[state[1]] ^ state[5] ^ state[9] ^ Mult_2[state[13]]);

    Temp[2] = (Mult_2[state[2]] ^ Mult_3[state[6]] ^ state[10] ^ state[14]);
    Temp[6] = (state[2] ^ Mult_2[state[6]] ^ Mult_3[state[10]] ^ state[14]);
    Temp[10] = (state[2] ^ state[6] ^ Mult_2[state[10]] ^ Mult_3[state[14]]);
    Temp[14] = (Mult_3[state[2]] ^ state[6] ^ state[10] ^ Mult_2[state[14]]);

    Temp[3] = (Mult_2[state[3]] ^ Mult_3[state[7]] ^ state[11] ^ state[15]);
    Temp[7] = (state[3] ^ Mult_2[state[7]] ^ Mult_3[state[11]] ^ state[15]);
    Temp[11] = (state[3] ^ state[7] ^ Mult_2[state[11]] ^ Mult_3[state[15]]);
    Temp[15] = (Mult_3[state[3]] ^ state[7] ^ state[11] ^ Mult_2[state[15]]);

    for(int i = 0; i<16; i++)
    {
        state[i] = Temp[i];
    }
}


unsigned char* Encryption(unsigned char* Plain_Text, unsigned char* key)
{
     unsigned char* state = new unsigned char[16]; //16 byte input for ease for AES-128
    
    
    for(int i = 0; i<16; i++)
    {
        state[i] = Plain_Text[i];
    }

    unsigned char** Round_Keys = new unsigned char*[15];
    for(int i = 0; i<15; i++)
    {
        Round_Keys[i] = new unsigned char[16];
    }



    int Total_Key[240];
    int Total_byte_count = 32;
    for (int i = 0; i < 32; i++)
	{
		Total_Key[i] = key[i]; // Saving the original key of 32 bytes
	}    

    unsigned char* Temp = new unsigned char[4];
    int rcon = 1;
    int Sub_byte = 48;

    //Creating 60 Words-----240 Bytes
    while (Total_byte_count < 240)
	{
		//Reading Last 4 bytes 
		for (int i = 0; i < 4; i++)
		{
			Temp[i] = Total_Key[i + Total_byte_count - 4];
		}

		//Doing Operation after each 32 bit key
		if (Total_byte_count % 32 == 0)
		{
			unsigned char t = Temp[0];
            Temp[0] = Temp[1];
            Temp[1] = Temp[2];
            Temp[2] = Temp[3];
            Temp[3] = t;

            //Substitution        
			for(int i = 0; i<4; i++)
            {
                Temp[i] = SBox[Temp[i]];
            }

            //Adding Round Constant = g(W[7])
            Temp[0] ^= Rcon[rcon++];
		}

		if (Total_byte_count==Sub_byte)
		{
            for(int i = 0; i<4; i++)
            {
                Temp[i] = SBox[Temp[i]];
            }
            Sub_byte+=32;
		}

		//XOR temp with [bytesgenerated-16] and store in expandedkeys;
		for (unsigned char j = 0; j < 4; j++)
		{
			Total_Key[Total_byte_count] = Total_Key[Total_byte_count - 32] ^ Temp[j];
			Total_byte_count++;
		}
	}

    
    //Setting Round Keys
    int byte = 0;
    for(int i = 0; i<15; i++)
    {
        for(int j = 0; j<16; j++)
        {
            Round_Keys[i][j] = Total_Key[byte++];
        }
    }

    //Storing Keys to use in decryption
    for(int i = 0; i<15; i++)
    {
        for(int j = 0; j<16; j++)
        {
            Stored_Key_256[i][j] = Round_Keys[i][j];
        }
    }
    
    cout<<"\n----------------------Round Keys-------------------------\n";
    cout<<"\n";
    for(int i = 0; i<15; i++)
    {
        cout<<"Round " + to_string(i) + " Key: ";
        Display_Hex(Round_Keys[i]);

    }

    //Createing state_matrix
    Create_state_Matrix(state,Plain_Text);

    //Initial Xor with state matrix
    Add_Round_Key(state,Round_Keys[0]);

    //Encryption Rounds
    for(int i = 1; i<14; i++)
    {
        Substitute_Bytes(state);
        Left_Shift_Rows(state);
        Mix_Columns(state);
        Add_Round_Key(state,Round_Keys[i]);
    }

     //Final Round of encryption
    Substitute_Bytes(state);
    Left_Shift_Rows(state);
    Add_Round_Key(state,Round_Keys[14]);

    
    //Converting state matrix to text form
    unsigned char* Encrypted_Text = new unsigned char[16];
    //Reversing state matrix
    Create_state_Matrix(Encrypted_Text,state);
    cout<<"\nEncrypted Text: ";
    Display_Hex(Encrypted_Text);
    cout<<"\n";

    return Encrypted_Text;


}


unsigned char* Block_Encryption(unsigned char* Plain_text, unsigned char* Key, int Text_Size)
{
    int Block_Count = 0;

        //Padding Kinda
        while(Text_Size%16!=0)
        {
            Text_Size++;
            Plain_text[Text_Size] = '0';
        }

        //Total Encrypted Array
        unsigned char* Encrypted_Text = new unsigned char[Text_Size];
      
        //Calulating Number of Blocks
        for(int i = 0; i<Text_Size; i++)
        {
            if(Text_Size%16==0)
            {
                Block_Count++;
            }
        }

        //Creating Text Blocks
        unsigned char** Blocks = new unsigned  char*[Block_Count];

        for(int i = 0; i<Block_Count+1; i++)
        {
            Blocks[i] = new unsigned char[16];
        }

        int z = 0;
        for(int i = 0; i<Block_Count+1; i++)
        {
            for(int j = 0; j<16; j++)
            {
                Blocks[i][j] = Plain_text[z++];
            }
        }

        for(int i = 0; i<Block_Count; i++)
        {
            for(int j = 0; j<16; j++)
            {
                cout<<Blocks[i][j];
            }
        }

        //Encrypting Blocks;
        for(int i = 0; i<Block_Count+1; i++)
        {
            Blocks[i] = Encryption(Blocks[i],Key);
        }
        int x = 0;
        for(int i = 0; i<Block_Count+1; i++)
        {
            for(int j = 0; j<16; j++)
            {
                Encrypted_Text[x++] = Blocks[i][j];
            }
        }

        Display_Encrypted_Text(Encrypted_Text,Text_Size);

        return Encrypted_Text;
}



