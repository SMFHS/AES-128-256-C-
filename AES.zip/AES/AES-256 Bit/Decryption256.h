#include <iostream>
using namespace std;

void Inverse_Mix_Columns(unsigned char* state)
{

	 unsigned char Temp[16];

    Temp[0] = (Mult_14[state[0]] ^ Mult_11[state[4]] ^ Mult_13[state[8]] ^ Mult_9[state[12]]);
	Temp[4] = (Mult_9[state[0]] ^ Mult_14[state[4]] ^ Mult_11[state[8]] ^ Mult_13[state[12]]);
	Temp[8] = (Mult_13[state[0]] ^ Mult_9[state[4]] ^ Mult_14[state[8]] ^ Mult_11[state[12]]);
	Temp[12] = (Mult_11[state[0]] ^ Mult_13[state[4]] ^ Mult_9[state[8]] ^ Mult_14[state[12]]);

	Temp[1] = (Mult_14[state[1]] ^ Mult_11[state[5]] ^ Mult_13[state[9]] ^ Mult_9[state[13]]);
	Temp[5] = (Mult_9[state[1]] ^ Mult_14[state[5]] ^ Mult_11[state[9]] ^ Mult_13[state[13]]);
	Temp[9] = (Mult_13[state[1]] ^ Mult_9[state[5]] ^ Mult_14[state[9]] ^ Mult_11[state[13]]);
	Temp[13] = (Mult_11[state[1]] ^ Mult_13[state[5]] ^ Mult_9[state[9]] ^ Mult_14[state[13]]);

	Temp[2] = (Mult_14[state[2]] ^ Mult_11[state[6]] ^ Mult_13[state[10]] ^ Mult_9[state[14]]);
	Temp[6] = (Mult_9[state[2]] ^ Mult_14[state[6]] ^ Mult_11[state[10]] ^ Mult_13[state[14]]);
	Temp[10] = (Mult_13[state[2]] ^ Mult_9[state[6]] ^ Mult_14[state[10]] ^ Mult_11[state[14]]);
	Temp[14] = (Mult_11[state[2]] ^ Mult_13[state[6]] ^ Mult_9[state[10]] ^ Mult_14[state[14]]);

	Temp[3] = (Mult_14[state[3]] ^ Mult_11[state[7]] ^ Mult_13[state[11]] ^ Mult_9[state[15]]);
	Temp[7] = (Mult_9[state[3]] ^ Mult_14[state[7]] ^ Mult_11[state[11]] ^ Mult_13[state[15]]);
	Temp[11] = (Mult_13[state[3]] ^ Mult_9[state[7]] ^ Mult_14[state[11]] ^ Mult_11[state[15]]);
	Temp[15] = (Mult_11[state[3]] ^ Mult_13[state[7]] ^ Mult_9[state[11]] ^ Mult_14[state[15]]);

    for(int i = 0; i<16; i++)
    {
        state[i] = Temp[i];
    }
}
void Inverse_Substitute_Bytes(unsigned char* state)
{
    for (int i = 0; i < 16; i++)
	{
		state[i] = SBox_Inverse[state[i]];
	}
}
void Inverse_Shift_Columns(unsigned char* state)
{
    unsigned char temp[16];
    for(int i = 0; i<16; i++)
    {
        temp[i] = state[i];
    }

	state[0] = temp[0];
	state[1] = temp[1];
	state[2] = temp[2];
	state[3] = temp[3];

	state[4] = temp[7];
	state[5] = temp[4];
	state[6] = temp[5];
	state[7] = temp[6];

	state[8] =  temp[10];
	state[9] =  temp[11];
	state[10] = temp[8];
	state[11] = temp[9];

	state[12] = temp[13];
	state[13] = temp[14];
	state[14] = temp[15];
	state[15] = temp[12];

     /*
    0 1 2 3           0 4 8 12
    4 5 6 7           1 5 9 13
    8 9 10 11         2 6 10 14
    12 13 14 15       3 7 11 15
    */
}

unsigned char* Decryption(unsigned char* Encrypted_Text)
{
    unsigned char** Reverse_Round_Keys = new unsigned char*[15];
    for(int i = 0; i<15; i++)
    {
        Reverse_Round_Keys[i] = new unsigned char[16];
    }

    //Reverse Stored Keys
    for(int i = 0, r = 14; r>=0, i<15;r--, i++)
    {
        for(int j = 0; j<16; j++)
        {
            Reverse_Round_Keys[i][j] = Stored_Key_256[r][j];
        }
    }

    cout<<"\n--------------------Reversed Round Keys-----------------------\n";
    for(int i = 0; i<15; i++)
    {
        cout<<"\nRound " + to_string(i) + " Key: ";
        Display_Hex(Reverse_Round_Keys[i]);
    
    }

    //Encrypted Text state matrix
    unsigned char* state_E = new unsigned char[16]; //16 byte input for ease for AES-128
    for(int i = 0; i<16; i++)
    {
        state_E[i] = Encrypted_Text[i];
    }     

    //Creating State Matrix
    Create_state_Matrix(state_E,Encrypted_Text);

    //Adding inital Round Key
    Add_Round_Key(state_E,Reverse_Round_Keys[0]);

    for(int i = 1; i<14; i++)
    {
        Inverse_Shift_Columns(state_E);
        Inverse_Substitute_Bytes(state_E);
        Add_Round_Key(state_E,Reverse_Round_Keys[i]);
        Inverse_Mix_Columns(state_E);

    }

    //Final Round
    Inverse_Shift_Columns(state_E);
    Inverse_Substitute_Bytes(state_E);
    Add_Round_Key(state_E,Reverse_Round_Keys[14]);


     unsigned char* Decrypted_Text = new unsigned char[16];
    //Reversing state matrix
    cout<<"\n-----------------------Decrypted Text-------------------------\n";
    Create_state_Matrix(Decrypted_Text,state_E);
    cout<<"\nDecrypted Text: ";
    Display(Decrypted_Text);
    cout<<"\n";

    return Decrypted_Text;


}

void Block_Decryption(unsigned char* Encrypt_text,int Text_Size)
{

    //int Text_Size = 0;
    int Block_Count = 0;
    //Taking Text from user and calculating number of Bytes of input

        //Total Encrypted Array
        unsigned char* Decrypted_Text = new unsigned char[Text_Size];
      
        //Calulating Number of Blocks
        for(int i = 0; i<Text_Size; i++)
        {
            if(Text_Size%16==0)
            {
                Block_Count++;
            }
        }

        //Creating Text Blocks
        unsigned char** Blocks = new unsigned  char*[Block_Count];

        for(int i = 0; i<Block_Count+1; i++)
        {
            Blocks[i] = new unsigned char[16];
        }

        int z = 0;
        for(int i = 0; i<Block_Count+1; i++)
        {
            for(int j = 0; j<16; j++)
            {
                Blocks[i][j] = Encrypt_text[z++];
            }
        }

        //Encrypting Blocks;
        for(int i = 0; i<Block_Count+1; i++)
        {
            Blocks[i] = Decryption(Blocks[i]);
        }
    
        int x = 0;
        for(int i = 0; i<Block_Count+1; i++)
        {
            for(int j = 0; j<16; j++)
            {
                Decrypted_Text[x++] = Blocks[i][j];
            }
        }
        
        Display_Decrypted_Text(Decrypted_Text,Text_Size);
}
