#include <iostream>
#include <iomanip>
#include <stdlib.h>
#include <string>
#include <sstream>
#include <iterator>
#include <cstring>
#include "D:\Google Classroom\5th Semester\Cryptography\AES\Globals.h"
#include "D:\Google Classroom\5th Semester\Cryptography\AES\Tables.h"
#include "Encryption256.h"
#include "Decryption256.h"


int main()
{
    
    unsigned char Plain_Text[] = "Two One Nine Two"; //16 byte input for ease for AES-256
    unsigned char key[33] = "Thats my Kung Fu Thats my Kung F"; //32 byte for AES-256     //32*8 = 256 bits
    unsigned char *Encrypted_Text = new unsigned char[16];
    unsigned char *Decrypted_Text = new unsigned char[16];
    Encrypted_Text = Encryption(Plain_Text,key);
    Decrypted_Text = Decryption(Encrypted_Text);

    /*unsigned char Key[32];
    unsigned char Plain_Text[1000]={0};
    unsigned char* E_Text;
    int Text_Size;

    
    cout<<"\n\n----------------------------------------AES-256 Encrypter/Decrypter----------------------------------------\n";
    
    
    cout<<"\nEnter Text to Encrypt: ";
    Text_Size = Text_Input(Plain_Text);
    Key_Input(Key);
    cout<<"\nKey : ";
    Display_Hex_256(Key);    
    E_Text = Block_Encryption(Plain_Text,Key,Text_Size);  //Encryption
    cout<<"\n";  
    Block_Decryption(E_Text,Text_Size); //Decryption*/  





}