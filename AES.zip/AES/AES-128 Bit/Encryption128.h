#include <iostream>
#include <string>
#include <sstream>
#include <iterator>
#include <cstring>
#include <math.h>

using namespace std;

//256 --- 14 rounds
//128 --- 10 rounds




void Substitute_Bytes(unsigned char* state)
{
    for(int i = 0; i<16; i++)
    {
        state[i] = SBox[state[i]];
    }
}

void Left_Shift_Rows(unsigned char* state)
{
    unsigned char temp[16];
    for(int i = 0; i<16; i++)
    {
        temp[i] = state[i];
    }

    state[0] = temp[0];
    state[1] = temp[1];
    state[2] = temp[2];
    state[3] = temp[3];

    state[4] = temp[5];
    state[5] = temp[6];
    state[6] = temp[7];
    state[7] = temp[4];

    state[8] = temp[10];
    state[9] = temp[11];
    state[10] = temp[8];
    state[11] = temp[9];

    state[12] = temp[15];
    state[13] = temp[12];
    state[14] = temp[13];
    state[15] = temp[14];
    /*
    0 1 2 3
    4 5 6 7
    8 9 10 11
    12 13 14 15
    */
}
void Mix_Columns(unsigned char* state)
{
    unsigned char Temp[16];

    Temp[0] = (Mult_2[state[0]] ^ Mult_3[state[4]] ^ state[8] ^ state[12]);
    Temp[4] = (state[0] ^ Mult_2[state[4]] ^ Mult_3[state[8]] ^ state[12]);
    Temp[8] = (state[0] ^ state[4] ^ Mult_2[state[8]] ^ Mult_3[state[12]]);
    Temp[12] = (Mult_3[state[0]] ^ state[4] ^ state[8] ^ Mult_2[state[12]]);

    Temp[1] = (Mult_2[state[1]] ^ Mult_3[state[5]] ^ state[9] ^ state[13]);
    Temp[5] = (state[1] ^ Mult_2[state[5]] ^ Mult_3[state[9]] ^ state[13]);
    Temp[9] = (state[1] ^ state[5] ^ Mult_2[state[9]] ^ Mult_3[state[13]]);
    Temp[13] = (Mult_3[state[1]] ^ state[5] ^ state[9] ^ Mult_2[state[13]]);

    Temp[2] = (Mult_2[state[2]] ^ Mult_3[state[6]] ^ state[10] ^ state[14]);
    Temp[6] = (state[2] ^ Mult_2[state[6]] ^ Mult_3[state[10]] ^ state[14]);
    Temp[10] = (state[2] ^ state[6] ^ Mult_2[state[10]] ^ Mult_3[state[14]]);
    Temp[14] = (Mult_3[state[2]] ^ state[6] ^ state[10] ^ Mult_2[state[14]]);

    Temp[3] = (Mult_2[state[3]] ^ Mult_3[state[7]] ^ state[11] ^ state[15]);
    Temp[7] = (state[3] ^ Mult_2[state[7]] ^ Mult_3[state[11]] ^ state[15]);
    Temp[11] = (state[3] ^ state[7] ^ Mult_2[state[11]] ^ Mult_3[state[15]]);
    Temp[15] = (Mult_3[state[3]] ^ state[7] ^ state[11] ^ Mult_2[state[15]]);

    for(int i = 0; i<16; i++)
    {
        state[i] = Temp[i];
    }


}

unsigned char* Generating_Round_Keys(unsigned char* k, unsigned char rc)
{
    //Dividing key into 4 sub keys
    unsigned char W0[4] = {k[0],k[1],k[2],k[3]};
    unsigned char W1[4] = {k[4],k[5],k[6],k[7]};
    unsigned char W2[4] = {k[8],k[9],k[10],k[11]};
    unsigned char W3[4] = {k[12],k[13],k[14],k[15]};


    unsigned char* GW3 = new unsigned char[4];
    for(int i = 0; i<4; i++)
    {
        GW3[i] = W3[i];
    }

    //circular byte left shift of W3
    unsigned char t = GW3[0];
    GW3[0] = GW3[1];
    GW3[1] = GW3[2];
    GW3[2] = GW3[3];
    GW3[3] = t;

    
    //Byte Substitution of W3 with SBox
    for(int i = 0; i<4; i++)
    {
        GW3[i] = SBox[GW3[i]];
    }

    //Adding Round Constant = g(W[3])
    GW3[0] ^= Rcon[rc];
    
    unsigned char W4[4],W5[4],W6[4],W7[4];
    //W4 = W0 ^ g(w[3])
    for(int i = 0; i<4; i++)
    {
        W4[i] = W0[i] ^ GW3[i];
    }
    //W5 = W4 ^ W1
    for(int i = 0; i<4; i++)
    {
        W5[i] = W4[i] ^ W1[i];
    }
    //W6 = W5 ^ W2
    for(int i = 0; i<4; i++)
    {
        W6[i] = W5[i] ^ W2[i];
    }
    //W7 = W6 XOR W3
    for(int i = 0; i<4; i++)
    {
        W7[i] = W6[i] ^ W3[i];
    }
  
    unsigned char* New_k = new unsigned char[16];
    int f = 0;
    for(int i = 0; i<4; i++)
    {
        New_k[f] = W4[i];
        f++;
    }
    for(int i = 0; i<4; i++)
    {
        New_k[f] = W5[i];
        f++;
    }
    for(int i = 0; i<4; i++)
    {
        New_k[f] = W6[i];
        f++;
    }
    for(int i = 0; i<4; i++)
    {
        New_k[f] = W7[i];
        f++;
    }
    return New_k;
}

void Display_Round_Matrices(unsigned char* state)
{
      for(int i = 0; i<16; i++)
    {
        if(i%4==0)
        {
            cout<<"\n";
        }
        cout<<hex<<int(state[i])<<" ";
    }
    cout<<"\n";
}

unsigned char** Return_Round_Keys(unsigned char** K)
{
    return K;
}

unsigned char* Encryption(unsigned char* P_T, unsigned char* K)
{
    unsigned char* state = new unsigned char[16]; //16 byte input for ease for AES-128
    for(int i = 0; i<16; i++)
    {
        state[i] = P_T[i];
    }     
    
    unsigned char** Round_Keys = new unsigned char*[11];
    for(int i = 0; i<11; i++)
    {
        Round_Keys[i] = new unsigned char[16];
    }
    Round_Keys[0] = K;

 cout<<"\n-----------------------Round Keys-------------------------\n";
    cout<<"\nRound 0 Key: ";
    Display_Hex(Round_Keys[0]);
    
    //Generating and storing Keys
    for(int i = 1; i<11; i++)
    {
        Round_Keys[i] = Generating_Round_Keys(Round_Keys[i-1],i);
    }

    //storing Keys to use in decryption
    for(int i = 0; i<11; i++)
    {
        for(int j = 0; j<16; j++)
        {
            Stored_Key_128[i][j] = Round_Keys[i][j];
        }
    }
    


   
    //Displaying Keys
    for(int i = 1; i<=10; i++)
    {
        cout<<"\nRound " + to_string(i) + " Key: ";
        Display_Hex(Round_Keys[i]);
    }

    //Createing state_matrix
    Create_state_Matrix(state,P_T);

    //Initial Xor with state matrix
    Add_Round_Key(state,Round_Keys[0]);
    //Nine Rounds of Encryption
   for(int i = 1; i<10; i++)
    {
       
        Substitute_Bytes(state);
        Left_Shift_Rows(state);
        Mix_Columns(state);
        Add_Round_Key(state,Round_Keys[i]);
    }

    //Final Round of encryption
    
    Substitute_Bytes(state);
    Left_Shift_Rows(state);
    Add_Round_Key(state,Round_Keys[10]);

    //Converting state matrix to text form
    unsigned char* Encrypted_Text = new unsigned char[16];
    //Reversing state matrix
    cout<<"\n-----------------------Encrypted Text-------------------------\n";
    Create_state_Matrix(Encrypted_Text,state);
    cout<<"\nEncrypted Text: ";
    Display_Hex(Encrypted_Text);
    cout<<"\n";

    return Encrypted_Text;
    
}
