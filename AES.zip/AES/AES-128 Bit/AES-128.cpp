#include <iostream>
#include "D:\Google Classroom\5th Semester\Cryptography\AES\Tables.h"
#include"D:\Google Classroom\5th Semester\Cryptography\AES\Globals.h"
#include "Encryption128.h"
#include "Decryption128.h"

using namespace std;




int main()
{
    
    unsigned char Plain_Text[] = "Two One Nine Two";
    unsigned char key[17] = "Thats my Kung Fu"; //16 byte for AES-128     //16*8 = 128 bits
    unsigned char* Encrypted_Text = new unsigned char[16];
    unsigned char* Decrypted_Text = new unsigned char[16];
    Encrypted_Text = Encryption(Plain_Text,key);
    Decrypted_Text = Decryption(Encrypted_Text);
    

   





   


   





}